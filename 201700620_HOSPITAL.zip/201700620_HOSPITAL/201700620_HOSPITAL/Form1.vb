﻿Public Class Form1

    Dim paciente1 As String() = {"paciente1", "1234567", "", "", "", "", "", "", "", ""}
    Dim paciente2 As String() = {"paciente2", "", "", "", "", "", "", "", "", ""}
    Dim paciente3 As String() = {"paciente3", "", "", "", "", "", "", "", "", ""}
    Dim paciente4 As String() = {"paciente4", "", "", "", "", "", "", "", "", ""}
    Dim paciente5 As String() = {"paciente5", "", "", "", "", "", "", "", "", ""}
    Dim paciente6 As String() = {"paciente6", "", "", "", "", "", "", "", "", ""}
    Dim pacientes()() As String = {paciente1, paciente2, paciente3, paciente4, paciente5, paciente6}

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For i As Integer = 0 To 5
            ListBox1.Items.Add(pacientes(i)(0))
        Next
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        Dim index As Integer = ListBox1.SelectedIndex
        Dim paciente As String() = pacientes(index)
        TextBox1.Text = paciente(0)
        TextBox2.Text = paciente(1)
        TextBox3.Text = paciente(2)
        TextBox4.Text = paciente(3)
        If paciente(4) = "1" Then
            RadioButton1.Checked = True
        ElseIf paciente(4) = "2" Then
            RadioButton2.Checked = True
        ElseIf paciente(4) = "3" Then
            RadioButton2.Checked = True
        End If
        If paciente(5) = "1" Then
            CheckBox1.Checked = True
        ElseIf paciente(5) = "2" Then
            CheckBox2.Checked = True
        ElseIf paciente(5) = "3" Then
            CheckBox3.Checked = True
        End If
        If paciente(6) = "1" Then
            RadioButton4.Checked = True
        ElseIf paciente(6) = "2" Then
            RadioButton5.Checked = True
        ElseIf paciente(6) = "3" Then
            RadioButton6.Checked = True
        ElseIf paciente(6) = "4" Then
            RadioButton7.Checked = True
        End If
        Label5.Text = "Subtotal: " + paciente(7)
        Label6.Text = "Descuento o recargo: " + paciente(8)
        Label7.Text = "Total: " + paciente(9)
    End Sub

    Private Sub CálculosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CálculosToolStripMenuItem.Click
        Dim subtotal As Double = 0.0
        If RadioButton1.Checked Then
            pacientes(ListBox1.SelectedIndex)(4) = "1"
            If CheckBox1.Checked Then
                subtotal = subtotal + 350.0
                pacientes(ListBox1.SelectedIndex)(5) = "1"
            End If
            If CheckBox2.Checked Then
                subtotal = subtotal + 550.0
                pacientes(ListBox1.SelectedIndex)(5) = "2"
            End If
            If CheckBox3.Checked Then
                subtotal = subtotal + 450.0
                pacientes(ListBox1.SelectedIndex)(5) = "3"
            End If
        ElseIf RadioButton2.Checked Then
            pacientes(ListBox1.SelectedIndex)(4) = "2"
            If CheckBox1.Checked Then
                subtotal = subtotal + 250.0
                pacientes(ListBox1.SelectedIndex)(5) = "1"
            End If
            If CheckBox2.Checked Then
                subtotal = subtotal + 400.0
                pacientes(ListBox1.SelectedIndex)(5) = "2"
            End If
            If CheckBox3.Checked Then
                subtotal = subtotal + 350.0
                pacientes(ListBox1.SelectedIndex)(5) = "3"
            End If
        ElseIf RadioButton3.Checked Then
            pacientes(ListBox1.SelectedIndex)(4) = "3"
            If CheckBox1.Checked Then
                subtotal = subtotal + 150.0
                pacientes(ListBox1.SelectedIndex)(5) = "1"
            End If
            If CheckBox2.Checked Then
                subtotal = subtotal + 300.0
                pacientes(ListBox1.SelectedIndex)(5) = "2"
            End If
            If CheckBox3.Checked Then
                subtotal = subtotal + 250.0
                pacientes(ListBox1.SelectedIndex)(5) = "3"
            End If
        End If
        subtotal = subtotal * TextBox3.Text
        subtotal = subtotal + TextBox4.Text

        Dim descuento_recargo As Double = 0.0
        If RadioButton4.Checked Then
            descuento_recargo = subtotal * -0.15
            pacientes(ListBox1.SelectedIndex)(6) = "1"
        ElseIf RadioButton5.Checked Then
            descuento_recargo = subtotal * -0.15
            pacientes(ListBox1.SelectedIndex)(6) = "2"
        ElseIf RadioButton7.Checked Then
            descuento_recargo = subtotal * -0.08
            pacientes(ListBox1.SelectedIndex)(6) = "3"
        ElseIf RadioButton6.Checked Then
            descuento_recargo = subtotal * 0.05
            pacientes(ListBox1.SelectedIndex)(6) = "4"
        End If

        Dim total As Double = subtotal + descuento_recargo

        pacientes(ListBox1.SelectedIndex)(0) = TextBox1.Text
        pacientes(ListBox1.SelectedIndex)(1) = TextBox2.Text
        pacientes(ListBox1.SelectedIndex)(2) = TextBox3.Text
        pacientes(ListBox1.SelectedIndex)(3) = TextBox4.Text
        pacientes(ListBox1.SelectedIndex)(7) = subtotal.ToString()
        pacientes(ListBox1.SelectedIndex)(8) = descuento_recargo.ToString()
        pacientes(ListBox1.SelectedIndex)(9) = total.ToString()

        Label5.Text = "Subtotal: " + subtotal.ToString()
        Label6.Text = "Descuento o recargo: " + descuento_recargo.ToString()
        Label7.Text = "Total: " + total.ToString()
    End Sub
End Class
